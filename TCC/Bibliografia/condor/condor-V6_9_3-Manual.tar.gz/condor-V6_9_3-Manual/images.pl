# LaTeX2HTML 2002-2-1 (1.70)
# Associate images original text with physical files.


$key = q/deltat;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$\delta t$">|; 

$key = q/pi_e(u,t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$\pi_e(u,t)$">|; 

$key = q/includegraphics{admin-manslashmachine-states.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="526" HEIGHT="347" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="\includegraphics{admin-man/machine-states.eps}">|; 

$key = q/includegraphics{admin-manslashview-screenshot.ps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="637" HEIGHT="587" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\includegraphics{admin-man/view-screenshot.ps}">|; 

$key = q/t=9+2^5=9+32=41seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="235" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="$t = 9 + 2^5 = 9 + 32 = 41 seconds$">|; 

$key = q/t=9+2^1=9+2=11seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="227" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="$t = 9 + 2^1 = 9 + 2 = 11 seconds$">|; 

$key = q/includegraphics{admin-manslashpool-arch.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="357" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\includegraphics{admin-man/pool-arch.eps}">|; 

$key = q/mathtt{backslash};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$\mathtt{\backslash}$">|; 

$key = q/{figure}preform{<verbatim_mark>verbatim2190#preform{{{{figure};FSF=1.6;AAF/;
$cached_env_img{$key} = q|<IMG
 WIDTH="316" HEIGHT="130" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="\begin{figure}\begin{verbatim}- (unary negation) (high precedence)
* /
+ -...
... &gt;= &gt;
== != =?= =!=
&amp;&amp;
\vert\vert (low precedence)\end{verbatim}
\end{figure}">|; 

$key = q/t=9+2^0=9+1=10seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="227" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="$t = 9 + 2^0 = 9 + 1 = 10 seconds$">|; 

$key = q/t=9+2^2=9+4=13seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="227" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$t = 9 + 2^2 = 9 + 4 = 13 seconds$">|; 

$key = q/{displaymath}pi_e(u,t)=pi_r(u,t)timesf(u,t){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="184" HEIGHT="28" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="\begin{displaymath}\pi_e(u,t) = \pi_r(u,t)\times f(u,t)\end{displaymath}">|; 

$key = q/{figure}{footnotesize{preform{<verbatim_mark>verbatim2189#preform{{normalsize{{{{figure};FSF=1.6;AAF/;
$cached_env_img{$key} = q|<IMG
 WIDTH="499" HEIGHT="147" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="\begin{figure}\footnotesize
\begin{verbatim}MyType = ''Machine''
TargetType = ...
...\vert LoadAvg&lt;=0.3 &amp;&amp; KeyboardIdle&gt;15*60\end{verbatim}
\normalsize\end{figure}">|; 

$key = q/pi_r(u,t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$\pi_r(u,t)$">|; 

$key = q/t=9+2^8=9+256=265seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="251" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$t = 9 + 2^8 = 9 + 256 = 265 seconds$">|; 

$key = q/fbox{Thissectionhasnotyetbeenwritten};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="276" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="\fbox{This section has not yet been written}">|; 

$key = q/{displaymath}pi_r(u,t)=betatimespi(u,t-deltat)+(1-beta)timesrho(u,t){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="308" HEIGHT="28" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="\begin{displaymath}\pi_r(u,t) = \beta\times\pi(u,t-\delta t) + (1-\beta)\times\rho(u,t)\end{displaymath}">|; 

$key = q/t=9+2^{12}=9+4096=4105seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="274" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$t = 9 + 2^{12} = 9 + 4096 = 4105 seconds$">|; 

$key = q/beta=0.5^{{deltat}slashh};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$\beta=0.5^{{\delta t}/h}$">|; 

$key = q/{figure}{small{preform{<verbatim_mark>verbatim201#preform{{normalsize{{{{figure};FSF=1.6;AAF/;
$cached_env_img{$key} = q|<IMG
 WIDTH="519" HEIGHT="500" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\begin{figure}\small
\begin{verbatim}MyType = ''Machine''
TargetType = ''Job''...
...k = - 1.000000
LastHeardFrom = 892191963\end{verbatim}
\normalsize\end{figure}">|; 

$key = q/backslash;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="$\backslash$">|; 

$key = q/includegraphics{gridsslashgfig1.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="580" HEIGHT="451" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="\includegraphics{grids/gfig1.eps}">|; 

$key = q/includegraphics{user-manslashdagman-node.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="346" HEIGHT="346" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\includegraphics{user-man/dagman-node.eps}">|; 

$key = q/includegraphics{user-manslashdagman-diamond.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="96" HEIGHT="96" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\includegraphics{user-man/dagman-diamond.eps}">|; 

$key = q/beta;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$\beta$">|; 

$key = q/rho(u,t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$\rho(u,t)$">|; 

$key = q/nomath_inline}textregisterednomath_inline};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\textregistered">|; 

$key = q/includegraphics{admin-manslashmachine-activities.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="660" HEIGHT="636" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="\includegraphics{admin-man/machine-activities.eps}">|; 

1;

